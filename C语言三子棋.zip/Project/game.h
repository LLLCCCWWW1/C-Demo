#define _CRT_SECURE_NO_WARNINGS
#ifndef __GAME_H__
#define __GAME_H__


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define ROW 3
#define COL 3
#define row ROW
#define col COL


void InitBoard(char board[ROW][COL]);
void DisPlayBoard(char board[ROW][COL]);
void PlayerGo(char board[ROW][COL]);
void AIGo(char board[ROW][COL]);
int IsFall(char board[ROW][COL]);
char IsWin(char board[ROW][COL]);

#endif
